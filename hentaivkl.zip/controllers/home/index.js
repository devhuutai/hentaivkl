const db = require("./../../utils/database");
const { resolve } = require("path");
const { formatTime } = require("./../../utils/time");
const moment = require("moment");
const { cacheMiddleware, saveCache } = require("./../../utils/redis"); // Thay đổi đường dẫn tới file middleware của bạn

exports.home = async (req, res, next) => {
  try {
    const dataCache = await cacheMiddleware(req, res, next);
    if (dataCache) {
      return res.render(`${resolve("./views/home/index")}`, {
        newUpdateFormat: dataCache.newUpdateFormat,
        urlSeo: dataCache.urlSeo,
        newProductsFormat: dataCache.newProductsFormat,
        categoriesFormat: dataCache.categoriesFormat,
        productsHOT: dataCache.productsHOT,
        dataConfigsFooter: dataCache.dataConfigsFooter,
        dataConfigsFooterTags: dataCache.dataConfigsFooterTags,
        dataConfigsFooterEmail: dataCache.dataConfigsFooterEmail,
        dataConfigsFooterCopy: dataCache.dataConfigsFooterCopy,
        dataConfigsFooterTitle: dataCache.dataConfigsFooterTitle,
        dataConfigsFooterKeywords: dataCache.dataConfigsFooterTitle,
        dataConfigsFooterDescription: dataCache.dataConfigsFooterTitle,
      });
    } else {
      const connection = await db.getConnection();
      const [dataNewUpdate] = await connection.query(`SELECT id, name, slug, thumb, histories FROM noah_products WHERE isDeleted IS NULL ORDER BY histories desc LIMIT 30`);
      const [dataNewProducts] = await connection.query(`SELECT id, name, slug, histories, creatAT, thumb FROM noah_products WHERE isDeleted IS NULL ORDER BY id DESC LIMIT 12`);
      const [dataProductsHOT] = await connection.query(`SELECT id, name, slug,  thumb FROM noah_products WHERE isTop = 1 AND isDeleted IS NULL LIMIT 6 `);
      const [dataCategories] = await connection.query(`SELECT id, name, slug FROM noah_cateogires WHERE isDeleted IS NULL ORDER BY ID DESC`);
      const [dataChapters] = await connection.query(`SELECT id, name, slug, idProducts FROM noah_chapters WHERE isDeleted IS NULL ORDER BY id ASC`);
      const [[dataConfigsFooter]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [1]);
      const [[dataConfigsFooterTags]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [2]);
      const [[dataConfigsFooterEmail]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [3]);
      const [[dataConfigsFooterCopy]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [4]);
      const [[dataConfigsFooterTitle]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [5]);
      const urlSeo = `http://localhost:4000`;

      const categoriesFormat = [];
      const newUpdateFormat = [];
      const newProductsFormat = [];
      const productsHOT = [];
      for (let c = 0; c < dataProductsHOT?.length; c++) {
        productsHOT.push({
          id: dataProductsHOT[c]?.id,
          name: dataProductsHOT[c]?.name,
          slug: dataProductsHOT[c]?.slug,
          thumb: dataProductsHOT[c]?.thumb ? `http://localhost:4000/thumb/${dataProductsHOT[c]?.thumb}` : `""`,
        });
      }
      for (let k = 0; k < dataCategories?.length; k++) {
        categoriesFormat.push({
          id: dataCategories[k]?.id,
          name: dataCategories[k]?.name,
          slug: dataCategories[k]?.slug,
        });
      }

      for (let j = 0; j < dataNewProducts?.length; j++) {
        const chapters = dataChapters?.filter((x) => x.idProducts == dataNewProducts[j].id)?.map((x) => x)[0];
        newProductsFormat.push({
          id: dataNewProducts[j].id,
          name: dataNewProducts[j].name,
          slug: dataNewProducts[j].slug,
          thumb: dataNewProducts[j]?.thumb ? `http://localhost:4000/thumb/${dataNewProducts[j]?.thumb}` : `""`,
          chapterName: chapters?.name || "Chưa có",
          chapterSlug: chapters?.slug || "",
          chapterId: chapters?.id || "",
          creatAT: dataNewProducts[j]?.creatAT ? await formatTime(dataNewProducts[j]?.creatAT) : "Chưa cập nhật",
        });
      }
      for (let i = 0; i < dataNewUpdate?.length; i++) {
        const chapters = dataChapters?.filter((x) => x.idProducts == dataNewUpdate[i].id)?.map((x) => x)[0];
        newUpdateFormat.push({
          id: dataNewUpdate[i].id,
          name: dataNewUpdate[i].name,
          slug: dataNewUpdate[i].slug,
          thumb: dataNewUpdate[i]?.thumb ? `http://localhost:4000/thumb/${dataNewUpdate[i]?.thumb}` : `""`,
          histories: dataNewUpdate[i]?.histories ? await formatTime(dataNewUpdate[i]?.histories?.[0]) : "Chưa cập nhật",
          chapterName: chapters?.name || "Chưa có",
          chapterSlug: chapters?.slug || "",
          chapterId: chapters?.id || "",
        });
      }
      connection.release();
      const dataCache = {
        newUpdateFormat: newUpdateFormat,
        urlSeo: urlSeo,
        newProductsFormat: newProductsFormat,
        categoriesFormat: categoriesFormat,
        productsHOT: productsHOT,
        dataConfigsFooter: dataConfigsFooter.data.data,
        dataConfigsFooterTags: dataConfigsFooterTags.data,
        dataConfigsFooterEmail: dataConfigsFooterEmail.data.email,
        dataConfigsFooterCopy: dataConfigsFooterCopy.data.copyright,
        dataConfigsFooterTitle: dataConfigsFooterTitle.data.title,
        dataConfigsFooterKeywords: dataConfigsFooterTitle.data.keywords,
        dataConfigsFooterDescription: dataConfigsFooterTitle.data.description,
      };
      const cacheData = await saveCache(dataCache, 360000);
      cacheData(req, res, async () => {
        console.log("Data cached: ", `${req.protocol}://${req.get("host")}${req.originalUrl}`);
      });
      return res.render(`${resolve("./views/home/index")}`, {
        newUpdateFormat: newUpdateFormat,
        urlSeo: urlSeo,
        newProductsFormat: newProductsFormat,
        categoriesFormat: categoriesFormat,
        productsHOT: productsHOT,
        dataConfigsFooter: dataConfigsFooter.data.data,
        dataConfigsFooterTags: dataConfigsFooterTags.data,
        dataConfigsFooterEmail: dataConfigsFooterEmail.data.email,
        dataConfigsFooterCopy: dataConfigsFooterCopy.data.copyright,
        dataConfigsFooterTitle: dataConfigsFooterTitle.data.title,
        dataConfigsFooterKeywords: dataConfigsFooterTitle.data.keywords,
        dataConfigsFooterDescription: dataConfigsFooterTitle.data.description,
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(404).json({ status: 404, msg: "Something wen't wrong" });
  }
};
exports.detail = async (req, res, next) => {
  try {
    const { slug } = req.params;
    const dataCache = await cacheMiddleware(req, res, next);
    if (dataCache) {
      return res.render(`${resolve("./views/home/detail")}`, {
        dataFormat: dataCache.dataFormat,
        urlSeo: dataCache.urlSeo,
        categoriesFormat: dataCache.categoriesFormat,
        dataConfigsFooter: dataCache.dataConfigsFooter,
        dataConfigsFooterTags: dataCache.dataConfigsFooterTags,
        dataConfigsFooterEmail: dataCache.dataConfigsFooterEmail,
        dataConfigsFooterCopy: dataCache.dataConfigsFooterCopy,
        dataConfigsFooterTitle: dataCache.dataConfigsFooterTitle,
        dataConfigsFooterKeywords: dataCache.dataConfigsFooterTitle,
        dataConfigsFooterDescription: dataCache.dataConfigsFooterTitle,
        newProductsFormat: dataCache.newProductsFormat,
        randomProductsFormat: dataCache.randomProductsFormat,
      });
    } else {
      const connection = await db.getConnection();
      const [[dataConfigsFooter]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [1]);
      const [[dataConfigsFooterTags]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [2]);
      const [[dataConfigsFooterEmail]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [3]);
      const [[dataConfigsFooterCopy]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [4]);
      const [[dataConfigsFooterTitle]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [5]);
      const [dataCategories] = await connection.query(`SELECT id, name, slug FROM noah_cateogires WHERE isDeleted IS NULL ORDER BY ID DESC`);
      const categoriesFormat = [];

      for (let k = 0; k < dataCategories?.length; k++) {
        categoriesFormat.push({
          id: dataCategories[k]?.id,
          name: dataCategories[k]?.name,
          slug: dataCategories[k]?.slug,
        });
      }

      const [[data]] = await connection.query(`SELECT id, name, slug, content, tags, status, idCategories, thumb, views FROM noah_products WHERE slug = ? AND isDeleted IS NULL`, [slug]);
      const [categories] = await connection.query(`SELECT id, name, slug FROM noah_cateogires where isDeleted IS NULL`);
      const [dataChapters] = await connection.query(`SELECT id, name, slug, idProducts, creatAT FROM noah_chapters WHERE isDeleted IS NULL AND idProducts = ?`, [data?.id]);
      const [dataNewProducts] = await connection.query(`SELECT id, name, slug, histories, creatAT, thumb FROM noah_products WHERE isDeleted IS NULL ORDER BY id DESC LIMIT 5`);
      const [randomProducts] = await connection.query(`SELECT id, name, slug, histories, creatAT, thumb FROM noah_products WHERE isDeleted IS NULL ORDER BY RAND() ASC LIMIT 5`);
      const firtsChapters = dataChapters?.filter((x) => x.idProducts == data.id)?.map((x) => x)[0];
      const urlSeo = `http://localhost:4000`;
      const dataChaptersFormat = [];
      const newProductsFormat = [];
      const randomProductsFormat = [];
      //check !data
      if (!data) {
        connection.release();
        return res.redirect("/");
      }
      for (let i = 0; i < dataChapters?.length; i++) {
        dataChaptersFormat.push({
          id: dataChapters[i]?.id,
          name: dataChapters[i]?.name,
          slug: dataChapters[i]?.slug,
          creatAT: dataChapters[i]?.creatAT ? moment(dataChapters[i]?.creatAT).format("DD/MM/YYYY") : "Chưa có",
        });
      }

      for (let j = 0; j < dataNewProducts?.length; j++) {
        const chapters = dataChapters?.filter((x) => x.idProducts == dataNewProducts[j].id)?.map((x) => x)[0];
        newProductsFormat.push({
          id: dataNewProducts[j].id,
          name: dataNewProducts[j].name,
          slug: dataNewProducts[j].slug,
          thumb: dataNewProducts[j]?.thumb ? `http://localhost:4000/thumb/${dataNewProducts[j]?.thumb}` : `""`,
          chapterName: chapters?.name || "Chưa có",
          chapterSlug: chapters?.slug || "",
          chapterId: chapters?.id || "",
          creatAT: dataNewProducts[j]?.creatAT ? await formatTime(dataNewProducts[j]?.creatAT) : "Chưa cập nhật",
        });
      }

      for (let k = 0; k < randomProducts?.length; k++) {
        const chapters = dataChapters?.filter((x) => x.idProducts == randomProducts[k].id)?.map((x) => x)[0];
        randomProductsFormat.push({
          id: randomProducts[k].id,
          name: randomProducts[k].name,
          slug: randomProducts[k].slug,
          thumb: randomProducts[k]?.thumb ? `http://localhost:4000/thumb/${randomProducts[k]?.thumb}` : `""`,
          chapterName: chapters?.name || "Chưa có",
          chapterSlug: chapters?.slug || "",
          chapterId: chapters?.id || "",
          creatAT: randomProducts[k]?.creatAT ? await formatTime(randomProducts[k]?.creatAT) : "Chưa cập nhật",
        });
      }

      const dataFormat = {
        id: data?.id,
        name: data?.name,
        slug: data?.slug,
        content: data?.content,
        tags: data?.tags ? JSON?.parse(data?.tags) : [],
        status: data?.status,
        views: data?.views ? data?.views : 0,
        categories: categories?.filter((x) => data?.idCategories?.includes(x?.id)),
        thumb: data?.thumb ? `http://localhost:4000/thumb/${data?.thumb}` : `""`,
        dataChaptersFormat: dataChaptersFormat,
        firtsChapters: firtsChapters,
      };
      connection.release();
      const dataCache = {
        dataFormat: dataFormat,
        urlSeo: urlSeo,
        categoriesFormat: categoriesFormat,
        dataConfigsFooter: dataConfigsFooter.data.data,
        dataConfigsFooterTags: dataConfigsFooterTags.data,
        dataConfigsFooterEmail: dataConfigsFooterEmail.data.email,
        dataConfigsFooterCopy: dataConfigsFooterCopy.data.copyright,
        dataConfigsFooterTitle: dataConfigsFooterTitle.data.title,
        dataConfigsFooterKeywords: dataConfigsFooterTitle.data.keywords,
        dataConfigsFooterDescription: dataConfigsFooterTitle.data.description,
        newProductsFormat: newProductsFormat,
        randomProductsFormat: randomProductsFormat,
      };
      const cacheData = await saveCache(dataCache, 360000);
      cacheData(req, res, async () => {
        console.log("Data cached: ", `${req.protocol}://${req.get("host")}${req.originalUrl}`);
      });
      return res.render(`${resolve("./views/home/detail")}`, {
        dataFormat: dataFormat,
        urlSeo: urlSeo,
        categoriesFormat: categoriesFormat,
        dataConfigsFooter: dataConfigsFooter.data.data,
        dataConfigsFooterTags: dataConfigsFooterTags.data,
        dataConfigsFooterEmail: dataConfigsFooterEmail.data.email,
        dataConfigsFooterCopy: dataConfigsFooterCopy.data.copyright,
        dataConfigsFooterTitle: dataConfigsFooterTitle.data.title,
        dataConfigsFooterKeywords: dataConfigsFooterTitle.data.keywords,
        dataConfigsFooterDescription: dataConfigsFooterTitle.data.description,
        newProductsFormat: newProductsFormat,
        randomProductsFormat: randomProductsFormat,
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(404).json({ status: 404, msg: "Something wen't wrong" });
  }
};
exports.categories = async (req, res, next) => {
  try {
    const dataCache = await cacheMiddleware(req, res, next);
    if (dataCache) {
      return res.render(`${resolve("./views/home/categories")}`, {
        dataFormat: dataCache.dataFormat,
        urlSeo: dataCache.urlSeo,
        categoriesIndex: dataCache.categoriesIndex,
        categoriesFormat: dataCache.categoriesFormat,
        dataConfigsFooter: dataCache.dataConfigsFooter,
        dataConfigsFooterTags: dataCache.dataConfigsFooterTags,
        dataConfigsFooterEmail: dataCache.dataConfigsFooterEmail,
        dataConfigsFooterCopy: dataCache.dataConfigsFooterCopy,
        dataConfigsFooterTitle: dataCache.dataConfigsFooterTitle,
        dataConfigsFooterKeywords: dataCache.dataConfigsFooterTitle,
        dataConfigsFooterDescription: dataCache.dataConfigsFooterTitle,
        total: dataCache.total || 1,
        totalPage: dataCache.totalPage || 1,
        page: dataCache.page || 1,
        limitPerPage: dataCache.limitPerPage,
        filterName: dataCache.filterName,
      });
    } else {
      let { page = 1, limitPerPage = 10, filterName } = req.query;
      const { slug } = req.params;
      let sqlExtra = "";
      const values = [];
      if (filterName) {
        sqlExtra += " AND ( name LIKE ? OR slug = ?)";
        values.push(`%${filterName}%`, `%${filterName}%`);
      }
      const offSet = (parseInt(page) - 1) * limitPerPage;
      if (isNaN(page) || isNaN(limitPerPage) || page < 1 || limitPerPage < 1) {
        return res.status(400).json({ message: "Invalid query parameters" });
      }
      const connection = await db.getConnection();
      const [[data]] = await connection.query(`SELECT id, name, slug, content, title FROM noah_cateogires WHERE isDeleted IS NULL  AND slug = ? `, [slug]);
      const categoryIds = data?.id;
      const [productData] = await connection.query(
        `SELECT id, name, slug, thumb, histories FROM noah_products WHERE isDeleted IS NULL AND JSON_CONTAINS(idCategories, ?) ${sqlExtra} ORDER BY id DESC LIMIT ? OFFSET ?`,
        [JSON.stringify(categoryIds), ...values, limitPerPage, offSet]
      );
      const [[dataConfigsFooter]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [1]);
      const [[dataConfigsFooterTags]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [2]);
      const [[dataConfigsFooterEmail]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [3]);
      const [[dataConfigsFooterCopy]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [4]);
      const [[dataConfigsFooterTitle]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [5]);
      const [dataCategories] = await connection.query(`SELECT id, name, slug FROM noah_cateogires WHERE isDeleted IS NULL ORDER BY ID DESC`);
      const categoriesFormat = [];
      const urlSeo = `http://localhost:4000`;

      for (let k = 0; k < dataCategories?.length; k++) {
        categoriesFormat.push({
          id: dataCategories[k]?.id,
          name: dataCategories[k]?.name,
          slug: dataCategories[k]?.slug,
        });
      }
      const [dataChapters] = await connection.query(`SELECT id, name, idProducts, creatAT, slug FROM noah_chapters WHERE isDeleted IS NULL ORDER BY id DESC `);
      const count = productData.length || 0;
      const totalPage = Math.ceil(productData.length / limitPerPage);
      const dataFormat = [];
      for (let i = 0; i < productData?.length; i++) {
        const chapters = dataChapters?.filter((x) => x.idProducts == productData[i]?.id)?.map((x) => x)[0] || "";
        dataFormat.push({
          id: productData[i]?.id,
          name: productData[i]?.name,
          slug: productData[i]?.slug,
          thumb: productData[i]?.thumb ? `http://localhost:4000/thumb/${productData[i]?.thumb}` : `""`,
          histories: productData[i]?.histories || "",
          idChapters: chapters?.id,
          nameChapters: chapters?.name || "Chưa có",
          slugChapters: chapters?.slug,
          timeChapters: chapters?.creatAT ? await formatTime(chapters?.creatAT) : "Chưa có",
        });
      }
      const categoriesIndex = {
        id: data?.id,
        name: data?.name,
        title: data?.title,
        slug: data?.slug,
        content: data?.content || "",
      };
      connection.release();
      const dataCache = {
        dataFormat: dataFormat,
        urlSeo: urlSeo,
        categoriesIndex: categoriesIndex,
        categoriesFormat: categoriesFormat,
        dataConfigsFooter: dataConfigsFooter.data.data,
        dataConfigsFooterTags: dataConfigsFooterTags.data,
        dataConfigsFooterEmail: dataConfigsFooterEmail.data.email,
        dataConfigsFooterCopy: dataConfigsFooterCopy.data.copyright,
        dataConfigsFooterTitle: dataConfigsFooterTitle.data.title,
        dataConfigsFooterKeywords: dataConfigsFooterTitle.data.keywords,
        dataConfigsFooterDescription: dataConfigsFooterTitle.data.description,
        total: count || 1,
        totalPage: totalPage || 1,
        page: page || 1,
        limitPerPage: limitPerPage,
        filterName: filterName,
      };
      const cacheData = await saveCache(dataCache, 360000);
      cacheData(req, res, async () => {
        console.log("Data cached: ", `${req.protocol}://${req.get("host")}${req.originalUrl}`);
      });
      return res.render(`${resolve("./views/home/categories")}`, {
        dataFormat: dataFormat,
        urlSeo: urlSeo,
        categoriesIndex: categoriesIndex,
        categoriesFormat: categoriesFormat,
        dataConfigsFooter: dataConfigsFooter.data.data,
        dataConfigsFooterTags: dataConfigsFooterTags.data,
        dataConfigsFooterEmail: dataConfigsFooterEmail.data.email,
        dataConfigsFooterCopy: dataConfigsFooterCopy.data.copyright,
        dataConfigsFooterTitle: dataConfigsFooterTitle.data.title,
        dataConfigsFooterKeywords: dataConfigsFooterTitle.data.keywords,
        dataConfigsFooterDescription: dataConfigsFooterTitle.data.description,
        total: count || 1,
        totalPage: totalPage || 1,
        page: page || 1,
        limitPerPage: limitPerPage,
        filterName: filterName,
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(404).json({ status: 404, msg: "Something wen't wrong" });
  }
};
exports.chapters = async (req, res, next) => {
  try {
    let { slug, chapter, id } = req.params;
    if (!req.session) {
      req.session = {};
    }
    if (!req.session?.history) {
      req.session.history = [];
    }
    const currentPage = { slug: slug, chapter: chapter, id: id };

    if (!req.session.history.some((page) => page.slug === slug && page.chapter === chapter && page.id === id)) {
      const findIndex = req.session.history?.findIndex((x) => x.slug === slug);
      if (findIndex !== -1) {
        req.session.history[findIndex] = currentPage;
      } else {
        req.session.history.push(currentPage);
      }
    }
    const dataCache = await cacheMiddleware(req, res, next);
    if (dataCache) {
      return res.render(`${resolve("./views/home/chapters")}`, {
        dataFormat: dataCache.dataFormat,
        urlSeo: dataCache.urlSeo,
        categoriesFormat: dataCache.categoriesFormat,
        dataConfigsFooter: dataCache.dataConfigsFooter,
        dataConfigsFooterTags: dataCache.dataConfigsFooterTags,
        dataConfigsFooterEmail: dataCache.dataConfigsFooterEmail,
        dataConfigsFooterCopy: dataCache.dataConfigsFooterCopyt,
        dataConfigsFooterTitle: dataCache.dataConfigsFooterTitle,
        dataConfigsFooterKeywords: dataCache.dataConfigsFooterTitle,
        dataConfigsFooterDescription: dataCache.dataConfigsFooterTitle,
        newProductsFormat: dataCache.newProductsFormat,
        listChapters: dataCache.listChapters,
      });
    } else {
      if (!slug || !chapter || !id) {
        return res.redirect("/");
      }
      const connection = await db.getConnection();
      const [[dataConfigsFooter]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [1]);
      const [[dataConfigsFooterTags]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [2]);
      const [[dataConfigsFooterEmail]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [3]);
      const [[dataConfigsFooterCopy]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [4]);
      const [[dataConfigsFooterTitle]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [5]);
      const [dataCategories] = await connection.query(`SELECT id, name, slug FROM noah_cateogires WHERE isDeleted IS NULL ORDER BY ID DESC`);
      const [dataNewProducts] = await connection.query(`SELECT id, name, slug, histories, creatAT, thumb FROM noah_products WHERE isDeleted IS NULL ORDER BY id DESC LIMIT 12`);
      const [dataChaptersProductNew] = await connection.query(`SELECT id, name, idProducts, creatAT, slug FROM noah_chapters WHERE isDeleted IS NULL ORDER BY id DESC `);
      const urlSeo = `http://localhost:4000`;

      const categoriesFormat = [];
      const newProductsFormat = [];
      for (let k = 0; k < dataCategories?.length; k++) {
        categoriesFormat.push({
          id: dataCategories[k]?.id,
          name: dataCategories[k]?.name,
          slug: dataCategories[k]?.slug,
        });
      }
      for (let j = 0; j < dataNewProducts?.length; j++) {
        const chapters = dataChaptersProductNew?.filter((x) => x.idProducts == dataNewProducts[j].id)?.map((x) => x)[0];
        newProductsFormat.push({
          id: dataNewProducts[j].id,
          name: dataNewProducts[j].name,
          slug: dataNewProducts[j].slug,
          thumb: dataNewProducts[j]?.thumb ? `http://localhost:4000/thumb/${dataNewProducts[j]?.thumb}` : `""`,
          chapterName: chapters?.name || "Chưa có",
          chapterSlug: chapters?.slug || "",
          chapterId: chapters?.id || "",
          creatAT: dataNewProducts[j]?.creatAT ? await formatTime(dataNewProducts[j]?.creatAT) : "Chưa cập nhật",
        });
      }
      const [[products]] = await connection.query(`SELECT id, name, slug, idCategories FROM noah_products WHERE slug = ? AND isDeleted IS NULL`, [slug]);
      if (!products) {
        connection.release();
        return res.status(404).json({ status: 404, msg: "Something wen't wrong" });
      }
      const idGategories = products?.idCategories?.map((x) => x)?.[0] || 1;
      const [[cateGoriesProducts]] = await connection.query(`SELECT id, name, slug FROM noah_cateogires WHERE isDeleted IS NULL AND id = ?`, idGategories);
      const [[dataChapters]] = await connection.query(`SELECT id, name, slug, chaptersImages, creatAT FROM noah_chapters WHERE slug = ? AND id = ? AND idProducts = ?`, [chapter, id, products?.id]);
      const [[prevChapter]] = await connection.query(` SELECT id, name, slug, chaptersImages, creatAT FROM noah_chapters WHERE idProducts = ? AND id < ? ORDER BY id DESC LIMIT 1`, [products?.id, id]);
      const [[nextChapter]] = await connection.query(`SELECT id, name, slug, chaptersImages, creatAT FROM noah_chapters WHERE idProducts = ? AND id > ? ORDER BY id ASC LIMIT 1`, [products?.id, id]);
      if (!dataChapters) {
        connection.release();
        return res.redirect("/");
      }
      const listChapters = dataChaptersProductNew?.filter((x) => x?.idProducts == products?.id)?.map((x) => x);
      const dataFormat = {
        id: dataChapters?.id,
        name: products?.name,
        slug: products?.slug,
        chapterName: dataChapters?.name,
        chapterSlug: dataChapters?.slug,
        categoriesName: cateGoriesProducts.name || "Chứa có",
        categoriesSlug: cateGoriesProducts.slug || "Chứa có",
        chaptersImages: dataChapters.chaptersImages.map((image) => `${req.protocol}://localhost:4000/${image.path?.replace("", "")}/${image.fileName}`),
        creatAT: moment(dataChapters?.creatAT).format("HH:SS DD-MM-YYYY"),
        prevChapter: prevChapter,
        nextChapter: nextChapter,
      };

      connection.release();
      const dataCache = {
        dataFormat: dataFormat,
        urlSeo: urlSeo,
        categoriesFormat: categoriesFormat,
        dataConfigsFooter: dataConfigsFooter.data.data,
        dataConfigsFooterTags: dataConfigsFooterTags.data,
        dataConfigsFooterEmail: dataConfigsFooterEmail.data.email,
        dataConfigsFooterCopy: dataConfigsFooterCopy.data.copyright,
        dataConfigsFooterTitle: dataConfigsFooterTitle.data.title,
        dataConfigsFooterKeywords: dataConfigsFooterTitle.data.keywords,
        dataConfigsFooterDescription: dataConfigsFooterTitle.data.description,
        newProductsFormat: newProductsFormat,
        listChapters: listChapters,
      };
      const cacheData = await saveCache(dataCache, 360000);
      cacheData(req, res, async () => {
        console.log("Data cached: ", `${req.protocol}://${req.get("host")}${req.originalUrl}`);
      });
      return res.render(`${resolve("./views/home/chapters")}`, {
        dataFormat: dataFormat,
        urlSeo: urlSeo,
        categoriesFormat: categoriesFormat,
        dataConfigsFooter: dataConfigsFooter.data.data,
        dataConfigsFooterTags: dataConfigsFooterTags.data,
        dataConfigsFooterEmail: dataConfigsFooterEmail.data.email,
        dataConfigsFooterCopy: dataConfigsFooterCopy.data.copyright,
        dataConfigsFooterTitle: dataConfigsFooterTitle.data.title,
        dataConfigsFooterKeywords: dataConfigsFooterTitle.data.keywords,
        dataConfigsFooterDescription: dataConfigsFooterTitle.data.description,
        newProductsFormat: newProductsFormat,
        listChapters: listChapters,
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(404).json({ status: 404, msg: "Something wen't wrong" });
  }
};
exports.tags = async (req, res, next) => {
  try {
    const dataCache = await cacheMiddleware(req, res, next);
    if (dataCache) {
      return res.render(`${resolve("./views/home/tags")}`, {
        dataFormat: dataCache.dataFormat,
        urlSeo: dataCache.urlSeo,
        categoriesFormat: dataCache.categoriesFormat,
        dataConfigsFooter: dataCache.dataConfigsFooter,
        dataConfigsFooterTags: dataCache.dataConfigsFooterTags,
        dataConfigsFooterEmail: dataCache.dataConfigsFooterEmail,
        dataConfigsFooterCopy: dataCache.dataConfigsFooterCopy,
        dataConfigsFooterTitle: dataCache.dataConfigsFooterTitle,
        dataConfigsFooterKeywords: dataCache.dataConfigsFooterTitle,
        dataConfigsFooterDescription: dataCache.dataConfigsFooterTitle,
        total: dataCache.total || 1,
        totalPage: dataCache.totalPage || 1,
        page: dataCache.page || 1,
        limitPerPage: dataCache.limitPerPage,
        filterName: dataCache.filterName,
        slug: dataCache.slug,
        firstTags: dataCache.firstTags,
      });
    } else {
      const { slug } = req.params;
      let { page = 1, limitPerPage = 10, filterName } = req.query;

      let sqlExtra = "";
      const values = [];
      if (filterName) {
        sqlExtra += " AND ( name LIKE ? OR slug = ?)";
        values.push(`%${filterName}%`, `%${filterName}%`);
      }
      const offSet = (parseInt(page) - 1) * limitPerPage;
      if (isNaN(page) || isNaN(limitPerPage) || page < 1 || limitPerPage < 1) {
        return res.status(400).json({ message: "Invalid query parameters" });
      }
      if (!slug) {
        return res.status(404).json({ status: 404, msg: "Something wen't wrong" });
      }
      const connection = await db.getConnection();
      const [data] = await connection.query(
        `SELECT id, name, slug, thumb, tags  FROM noah_products WHERE isDeleted IS NULL  AND JSON_CONTAINS(tags, '{"changeString": "${slug}"}') ${sqlExtra} ORDER BY id DESC LIMIT ? OFFSET ?`,
        [...values, limitPerPage, offSet]
      );
      const [[count]] = await connection.query(
        `SELECT COUNT(id) as total FROM noah_products WHERE isDeleted IS NULL  AND JSON_CONTAINS(tags, '{"changeString": "${slug}"}') ${sqlExtra} ORDER BY id DESC LIMIT ? OFFSET ?`,
        [...values, limitPerPage, offSet]
      );
      const totalPage = Math.ceil(count.total / limitPerPage);
      const [[dataConfigsFooter]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [1]);
      const [[dataConfigsFooterTags]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [2]);
      const [[dataConfigsFooterEmail]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [3]);
      const [[dataConfigsFooterCopy]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [4]);
      const [[dataConfigsFooterTitle]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [5]);
      const [dataCategories] = await connection.query(`SELECT id, name, slug FROM noah_cateogires WHERE isDeleted IS NULL ORDER BY ID DESC`);
      const categoriesFormat = [];
      const dataFormat = [];
      const [dataChapters] = await connection.query(`SELECT id, name, idProducts, creatAT, slug FROM noah_chapters WHERE isDeleted IS NULL ORDER BY id DESC `);
      const urlSeo = `http://localhost:4000`;

      for (let k = 0; k < dataCategories?.length; k++) {
        categoriesFormat.push({
          id: dataCategories[k]?.id,
          name: dataCategories[k]?.name,
          slug: dataCategories[k]?.slug,
        });
      }

      for (let i = 0; i < data?.length; i++) {
        const chapters = dataChapters?.filter((x) => x.idProducts == data[i]?.id)?.map((x) => x)[0] || "";
        dataFormat.push({
          id: data[i]?.id,
          name: data[i]?.name,
          slug: data[i]?.slug,
          thumb: data[i]?.thumb ? `http://localhost:4000/thumb/${data[i]?.thumb}` : `""`,
          histories: data[i]?.histories || "",
          idChapters: chapters?.id,
          nameChapters: chapters?.name || "Chưa có",
          slugChapters: chapters?.slug,
          timeChapters: chapters?.creatAT ? await formatTime(chapters?.creatAT) : "Chưa có",
          tags: data[i]?.tags,
        });
      }
      const firstTags = {
        nameTags: dataFormat[0]?.tags ? JSON.parse(dataFormat[0]?.tags)?.map((x) => x.title)[0] : "",
        slugTags: dataFormat[0]?.tags ? JSON.parse(dataFormat[0]?.tags)?.map((x) => x.changeString)[0] : "",
      };
      connection.release();
      const dataCache = {
        dataFormat: dataFormat,
        urlSeo: urlSeo,
        categoriesFormat: categoriesFormat,
        dataConfigsFooter: dataConfigsFooter.data.data,
        dataConfigsFooterTags: dataConfigsFooterTags.data,
        dataConfigsFooterEmail: dataConfigsFooterEmail.data.email,
        dataConfigsFooterCopy: dataConfigsFooterCopy.data.copyright,
        dataConfigsFooterTitle: dataConfigsFooterTitle.data.title,
        dataConfigsFooterKeywords: dataConfigsFooterTitle.data.keywords,
        dataConfigsFooterDescription: dataConfigsFooterTitle.data.description,
        total: count || 1,
        totalPage: totalPage || 1,
        page: page || 1,
        limitPerPage: limitPerPage,
        filterName: filterName,
        slug: slug,
        firstTags: firstTags,
      };
      const cacheData = await saveCache(dataCache, 360000);
      cacheData(req, res, async () => {
        console.log("Data cached: ", `${req.protocol}://${req.get("host")}${req.originalUrl}`);
      });
      return res.render(`${resolve("./views/home/tags")}`, {
        dataFormat: dataFormat,
        urlSeo: urlSeo,
        categoriesFormat: categoriesFormat,
        dataConfigsFooter: dataConfigsFooter.data.data,
        dataConfigsFooterTags: dataConfigsFooterTags.data,
        dataConfigsFooterEmail: dataConfigsFooterEmail.data.email,
        dataConfigsFooterCopy: dataConfigsFooterCopy.data.copyright,
        dataConfigsFooterTitle: dataConfigsFooterTitle.data.title,
        dataConfigsFooterKeywords: dataConfigsFooterTitle.data.keywords,
        dataConfigsFooterDescription: dataConfigsFooterTitle.data.description,
        total: count || 1,
        totalPage: totalPage || 1,
        page: page || 1,
        limitPerPage: limitPerPage,
        filterName: filterName,
        slug: slug,
        firstTags: firstTags,
      });
    }
  } catch (err) {
    console.log(err);
    return res.status(404).json({ status: 404, msg: "Something wen't wrong" });
  }
};
exports.histories = async (req, res, next) => {
  try {
    let dataHistories = req.session.history || [];
    const connection = await db.getConnection();
    const [data] = await connection.query(`SELECT id, name, slug, thumb FROM noah_products WHERE isDeleted IS NULL`);
    const [[dataConfigsFooter]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [1]);
    const [[dataConfigsFooterTags]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [2]);
    const [[dataConfigsFooterEmail]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [3]);
    const [[dataConfigsFooterCopy]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [4]);
    const [[dataConfigsFooterTitle]] = await connection.query(`SELECT id, name, data FROM noah_configs WHERE id = ?`, [5]);
    const [dataCategories] = await connection.query(`SELECT id, name, slug FROM noah_cateogires WHERE isDeleted IS NULL ORDER BY ID DESC`);
    const categoriesFormat = [];

    for (let k = 0; k < dataCategories?.length; k++) {
      categoriesFormat.push({
        id: dataCategories[k]?.id,
        name: dataCategories[k]?.name,
        slug: dataCategories[k]?.slug,
      });
    }
    const urlSeo = `http://localhost:4000`;
    const dataFormat = [];
    for (let i = 0; i < dataHistories?.length; i++) {
      let slugChapter = dataHistories[i]?.chapter;
      let products = data?.find((x) => x.slug == dataHistories[i]?.slug);
      let idChapters = dataHistories[i]?.id;
      const [[chapters]] = await connection.query(`SELECT id, name, slug FROM  noah_chapters WHERE isDeleted IS NULL AND slug = ? AND id = ?`, [slugChapter, idChapters]);
      dataFormat.push({
        id: products.id,
        slug: products?.slug,
        name: products?.name,
        thumb: products?.thumb ? `http://localhost:4000/thumb/${products?.thumb}` : `""`,
        nameChapter: chapters?.name,
        chapterSlug: chapters?.slug,
        idChapters: idChapters,
      });
    }
    connection.release();
    return res.render(`${resolve("./views/home/histories")}`, {
      dataFormat: dataFormat,
      urlSeo: urlSeo,
      categoriesFormat: categoriesFormat,
      dataConfigsFooter: dataConfigsFooter.data.data,
      dataConfigsFooterTags: dataConfigsFooterTags.data,
      dataConfigsFooterEmail: dataConfigsFooterEmail.data.email,
      dataConfigsFooterCopy: dataConfigsFooterCopy.data.copyright,
      dataConfigsFooterTitle: dataConfigsFooterTitle.data.title,
      dataConfigsFooterKeywords: dataConfigsFooterTitle.data.keywords,
      dataConfigsFooterDescription: dataConfigsFooterTitle.data.description,
    });
  } catch (err) {
    console.log(err);
    return res.status(404).json({ status: 404, msg: "Something wen't wrong" });
  }
};
