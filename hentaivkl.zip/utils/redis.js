const Redis = require("ioredis");
const redis = new Redis();

exports.cacheMiddleware = async (req, res) => {
  try {
    const cacheKey = req.originalUrl;
    const cachedData = await redis.get(cacheKey);
    if (cachedData) {
      const parsedData = JSON.parse(cachedData);
      return (res.locals.cachedData = parsedData);
    }
  } catch (err) {
    console.log(err);
    return res.status(404).json({ msg: "Error get cached" });
  }
};

exports.saveCache = async (data, time) => {
  return async (req, res, next) => {
    try {
      const cacheKey = req.originalUrl;
      await redis.set(cacheKey, JSON.stringify(data), "EX", time);
      next();
    } catch (err) {
      console.log(err);
      return res.status(404).json({ msg: "error save cache" });
    }
  };
};
